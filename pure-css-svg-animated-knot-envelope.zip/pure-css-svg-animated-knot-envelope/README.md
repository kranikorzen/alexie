# Pure CSS svg animated knot envelope

A Pen created on CodePen.

Original URL: [https://codepen.io/reed2k24/pen/zxBNLPP](https://codepen.io/reed2k24/pen/zxBNLPP).

CSS animated envelope with animated svg string untying